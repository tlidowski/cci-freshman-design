This work was released by thekingphoenix under the Creative Commons 0 license which equals the Public Domain.

The spritesheets and seven color variations were made by Bonsaiheldin (http://bonsaiheld.org).

Enjoy!
